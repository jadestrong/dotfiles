require "modules/hotkey"
-- require "modules/screens"
require "modules/windows"
require "modules/launch"
-- require "modules/system"
require "modules/auto_reload"
local bindings = require "bindings"

bindings.init()
