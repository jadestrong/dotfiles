hyper = {'ctrl', 'cmd'}
hyperShift = {'ctrl', 'cmd', 'shift'}